package com.example.commandblocklogger.commands;

import com.example.commandblocklogger.CommandBlockLoggerMod;
import com.mojang.brigadier.CommandDispatcher;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2561;

import static net.minecraft.class_2170.method_9247;

public final class CommandBlockLoggerCommands {
    private CommandBlockLoggerCommands() {}

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> register(dispatcher));
    }

    private static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(method_9247("commandblocklogger")
                .requires(source -> true)
                .then(method_9247("reload").executes(ctx -> {
                    CommandBlockLoggerMod.reloadConfig();
                    ctx.getSource().method_9226(() -> class_2561.method_43470("CommandBlockLogger config reloaded."), false);
                    return 1;
                }))
                .then(method_9247("stats").executes(ctx -> {
                    var stats = CommandBlockLoggerMod.stats();
                    ctx.getSource().method_9226(() -> class_2561.method_43470(
                            "CommandBlockLogger stats: total=" + stats.totalCommands()
                                    + ", failed=" + stats.failedCommands()
                                    + ", failureRate=" + String.format("%.2f", stats.failureRate()) + "%"
                    ), false);
                    stats.topCommands(8).forEach((cmd, count) ->
                            ctx.getSource().method_9226(() -> class_2561.method_43470(" - " + cmd + ": " + count), false)
                    );
                    return 1;
                }))
                .then(method_9247("enable").executes(ctx -> {
                    var cfg = CommandBlockLoggerMod.config();
                    cfg.enabled = true;
                    cfg.save();
                    CommandBlockLoggerMod.reloadConfig();
                    ctx.getSource().method_9226(() -> class_2561.method_43470("CommandBlockLogger enabled."), false);
                    return 1;
                }))
                .then(method_9247("disable").executes(ctx -> {
                    var cfg = CommandBlockLoggerMod.config();
                    cfg.enabled = false;
                    cfg.save();
                    CommandBlockLoggerMod.reloadConfig();
                    ctx.getSource().method_9226(() -> class_2561.method_43470("CommandBlockLogger disabled."), false);
                    return 1;
                }))
        );
    }
}
