package com.example.commandblocklogger.mixin;

import com.example.commandblocklogger.CommandBlockLoggerMod;
import com.example.commandblocklogger.events.CommandBlockExecutionEvent;
import com.example.commandblocklogger.util.CommandBlockTypeResolver;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.time.Instant;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import net.minecraft.class_1918;
import net.minecraft.class_2288;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

@Mixin(class_2288.class)
public abstract class CommandBlockMixin {
    @Unique
    private static final DateTimeFormatter CBL_TIME_FORMAT = DateTimeFormatter.ofPattern("HH:mm:ss");

    @Inject(method = "execute", at = @At("RETURN"))
    private void commandblocklogger$afterExecute(
            class_2680 state,
            class_3218 world,
            class_2338 pos,
            class_1918 executor,
            boolean hasCommand,
            CallbackInfo ci
    ) {
        try {
            if (!hasCommand || executor == null) return;

            String command = executor.method_8289();
            class_2561 outputText = executor.method_8292();
            String output = outputText == null ? "" : outputText.getString();

            int successCount = executor.method_8304();
            boolean success = successCount > 0;

            CommandBlockExecutionEvent event = new CommandBlockExecutionEvent(
                    Instant.now(),
                    LocalTime.now().format(CBL_TIME_FORMAT),
                    world.method_27983().method_29177().toString(),
                    pos.method_10062(),
                    CommandBlockTypeResolver.resolve(state),
                    command,
                    success ? "SUCCESS" : "FAILED",
                    successCount,
                    output,
                    "command_block",
                    success ? "" : output
            );

            CommandBlockLoggerMod.logService().submit(event);
        } catch (Throwable t) {
            CommandBlockLoggerMod.LOGGER.error("Failed to capture command block execution.", t);
        }
    }
}
