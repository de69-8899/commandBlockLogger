package com.example.commandblocklogger.util;

import net.minecraft.class_2246;
import net.minecraft.class_2680;

public final class CommandBlockTypeResolver {
    private CommandBlockTypeResolver() {}

    public static String resolve(class_2680 state) {
        if (state == null) return "UNKNOWN";
        if (state.method_27852(class_2246.field_10395)) return "CHAIN";
        if (state.method_27852(class_2246.field_10263)) return "REPEAT";
        if (state.method_27852(class_2246.field_10525)) return "IMPULSE";
        return "UNKNOWN";
    }
}
