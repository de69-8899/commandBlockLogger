package com.example.commandblocklogger.events;

import java.time.Instant;
import net.minecraft.class_2338;

public record CommandBlockExecutionEvent(
        Instant timestamp,
        String time,
        String world,
        class_2338 pos,
        String commandBlockType,
        String command,
        String status,
        int result,
        String output,
        String triggerSource,
        String error
) {
    public boolean failed() {
        return "FAILED".equalsIgnoreCase(status);
    }
}
